enum AppRole { admin, operator, maintenance, viewer }

class AppUser {
  final String id;
  final String name;
  final String email;
  final AppRole role;
  final String assignedArea;
  final bool enabled;

  const AppUser({
    required this.id,
    required this.name,
    required this.email,
    required this.role,
    required this.assignedArea,
    required this.enabled,
  });

  AppUser copyWith({
    String? id,
    String? name,
    String? email,
    AppRole? role,
    String? assignedArea,
    bool? enabled,
  }) {
    return AppUser(
      id: id ?? this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      role: role ?? this.role,
      assignedArea: assignedArea ?? this.assignedArea,
      enabled: enabled ?? this.enabled,
    );
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'id': id,
      'name': name,
      'email': email.trim().toLowerCase(),
      'role': role.name,
      'assignedArea': assignedArea,
      'enabled': enabled,
    };
  }

  factory AppUser.fromMap(Map<String, dynamic> map, {String? fallbackId}) {
    final rawRole = (map['role'] ?? 'viewer').toString();
    return AppUser(
      id: (map['id'] ?? fallbackId ?? '').toString(),
      name: (map['name'] ?? '').toString(),
      email: (map['email'] ?? '').toString(),
      role: AppRole.values.firstWhere(
        (value) => value.name == rawRole,
        orElse: () => AppRole.viewer,
      ),
      assignedArea: (map['assignedArea'] ?? '').toString(),
      enabled: (map['enabled'] ?? true) == true,
    );
  }
}
