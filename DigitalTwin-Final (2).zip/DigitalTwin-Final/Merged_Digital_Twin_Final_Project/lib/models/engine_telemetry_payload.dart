/// Immutable representation of one engine telemetry MQTT message.
class EngineTelemetryPayload {
  const EngineTelemetryPayload({
    required this.engineId,
    required this.currentCycle,
    required this.predictedRul,
    required this.currentSensorReadings,
    required this.aiRootCauses,
  });

  final int engineId;
  final int currentCycle;
  final double predictedRul;
  final Map<String, double> currentSensorReadings;
  final Map<String, double> aiRootCauses;

  factory EngineTelemetryPayload.fromJson(Map<String, dynamic> json) {
    return EngineTelemetryPayload(
      engineId: _asInt(json['engine_id']),
      currentCycle: _asInt(json['current_cycle']),
      predictedRul: _asDouble(json['predicted_rul']),
      currentSensorReadings: _asDoubleMap(json['current_sensor_readings']),
      aiRootCauses: _asDoubleMap(json['ai_root_causes']),
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'engine_id': engineId,
        'current_cycle': currentCycle,
        'predicted_rul': predictedRul,
        'current_sensor_readings': currentSensorReadings,
        'ai_root_causes': aiRootCauses,
      };
}

int _asInt(Object? value) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  throw FormatException('Expected int-compatible value, got $value');
}

double _asDouble(Object? value) {
  if (value is double) return value;
  if (value is num) return value.toDouble();
  throw FormatException('Expected num value, got $value');
}

Map<String, double> _asDoubleMap(Object? value) {
  if (value is! Map) {
    throw FormatException('Expected JSON object map, got $value');
  }
  return value.map<String, double>(
    (Object? key, Object? v) => MapEntry(key.toString(), _asDouble(v)),
  );
}
