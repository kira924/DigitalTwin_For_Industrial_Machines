import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app/state.dart';
import '../models/app_user.dart';
import '../models/machine.dart';
import '../theme/dt_colors.dart';

Future<void> showMachineFormSheet(BuildContext context, {Machine? machine}) {
  final name = TextEditingController(text: machine?.name ?? '');
  final code = TextEditingController(text: machine?.code ?? '');
  final type = TextEditingController(text: machine?.type ?? '');
  final location = TextEditingController(text: machine?.location ?? '');
  final images = const <String>[
    'assets/images/machine_cnc.png',
    'assets/images/machine_robotic.png',
    'assets/images/machine_press.png',
    'assets/images/machine_conveyor.png',
    'assets/images/machine_lathe.png',
    'assets/images/machine_welding.png',
    'assets/images/machine_assembly.png',
    'assets/images/machine_packaging.png',
  ];
  String selectedImage = machine?.imagePath ?? images.first;
  MachineStatus selectedStatus = machine?.status ?? MachineStatus.running;

  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: const Color(0xFF07111F),
    builder: (_) {
      return StatefulBuilder(
        builder: (context, setState) {
          return Padding(
            padding: EdgeInsets.fromLTRB(
              18,
              18,
              18,
              18 + MediaQuery.of(context).viewInsets.bottom,
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    machine == null ? 'Add Machine' : 'Edit Machine',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 24,
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: name,
                    decoration: const InputDecoration(labelText: 'Machine name'),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: code,
                    decoration: const InputDecoration(labelText: 'Machine ID / Code'),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: type,
                    decoration: const InputDecoration(labelText: 'Machine type'),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: location,
                    decoration: const InputDecoration(labelText: 'Location'),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<MachineStatus>(
                    value: selectedStatus,
                    decoration: const InputDecoration(labelText: 'Status'),
                    items: MachineStatus.values
                        .map(
                          (status) => DropdownMenuItem(
                            value: status,
                            child: Text(_machineStatusText(status)),
                          ),
                        )
                        .toList(growable: false),
                    onChanged: (value) => setState(
                      () => selectedStatus = value ?? MachineStatus.running,
                    ),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: selectedImage,
                    decoration:
                        const InputDecoration(labelText: 'Photo / illustration'),
                    items: images
                        .map(
                          (path) => DropdownMenuItem(
                            value: path,
                            child: Text(path.split('/').last),
                          ),
                        )
                        .toList(growable: false),
                    onChanged: (value) => setState(
                      () => selectedImage = value ?? images.first,
                    ),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () {
                        final app = context.read<AppState>();
                        final item = Machine(
                          id: machine?.id ??
                              code.text.trim().toLowerCase().replaceAll(' ', '-'),
                          name: name.text.trim(),
                          type: type.text.trim(),
                          code: code.text.trim(),
                          location: location.text.trim(),
                          imagePath: selectedImage,
                          status: selectedStatus,
                          efficiency: machine?.efficiency ?? 88,
                          temperature: machine?.temperature ?? 42,
                          speed: machine?.speed ?? 120,
                          vibration: machine?.vibration ?? 0.18,
                          power: machine?.power ?? 9.8,
                          pressure: machine?.pressure ?? 8,
                          productionCount: machine?.productionCount ?? 0,
                          productionRate: machine?.productionRate ?? 84,
                          activeAlert: machine?.activeAlert,
                          lastUpdated: DateTime.now(),
                          performanceSeries: machine?.performanceSeries ?? const [
                            MachineMetricPoint(label: '10:00', value: 82),
                            MachineMetricPoint(label: '10:15', value: 86),
                            MachineMetricPoint(label: '10:30', value: 88),
                            MachineMetricPoint(label: '10:45', value: 91),
                          ],
                          sensors: machine?.sensors ?? const [
                            MachineSensor(
                              label: 'Vibration',
                              unit: 'mm/s',
                              value: 0.18,
                              color: DT.green,
                            ),
                            MachineSensor(
                              label: 'Noise Level',
                              unit: 'dB',
                              value: 72,
                              color: DT.blue,
                            ),
                            MachineSensor(
                              label: 'Oil Pressure',
                              unit: 'PSI',
                              value: 45,
                              color: DT.cyan,
                            ),
                          ],
                          timeline: machine?.timeline ?? [
                            MachineTimelineEvent(
                              time: DateTime.now(),
                              title: 'Machine created',
                              detail: 'Machine record was created by admin.',
                              color: DT.cyan,
                            ),
                          ],
                        );
                        if (machine == null) {
                          app.addMachine(item);
                        } else {
                          app.updateMachine(item);
                        }
                        Navigator.pop(context);
                      },
                      child: Text(
                        machine == null ? 'Save machine' : 'Update machine',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  );
}

Future<void> showUserFormSheet(BuildContext context, {AppUser? user}) {
  final name = TextEditingController(text: user?.name ?? '');
  final email = TextEditingController(text: user?.email ?? '');
  final area = TextEditingController(text: user?.assignedArea ?? '');
  AppRole selectedRole = user?.role ?? AppRole.viewer;
  bool enabled = user?.enabled ?? true;

  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: const Color(0xFF07111F),
    builder: (_) {
      return StatefulBuilder(
        builder: (context, setState) {
          return Padding(
            padding: EdgeInsets.fromLTRB(
              18,
              18,
              18,
              18 + MediaQuery.of(context).viewInsets.bottom,
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    user == null ? 'Add User' : 'Edit User',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 24,
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: name,
                    decoration: const InputDecoration(labelText: 'Full name'),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: email,
                    decoration: const InputDecoration(labelText: 'Email'),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: area,
                    decoration: const InputDecoration(labelText: 'Assigned area'),
                  ),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<AppRole>(
                    value: selectedRole,
                    decoration: const InputDecoration(labelText: 'Role'),
                    items: AppRole.values
                        .map(
                          (role) => DropdownMenuItem(
                            value: role,
                            child: Text(role.name),
                          ),
                        )
                        .toList(growable: false),
                    onChanged: (value) =>
                        setState(() => selectedRole = value ?? AppRole.viewer),
                  ),
                  SwitchListTile.adaptive(
                    value: enabled,
                    onChanged: (v) => setState(() => enabled = v),
                    title: const Text(
                      'Enabled',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () {
                        final item = AppUser(
                          id: user?.id ?? email.text.trim(),
                          name: name.text.trim(),
                          email: email.text.trim(),
                          role: selectedRole,
                          assignedArea: area.text.trim(),
                          enabled: enabled,
                        );
                        final app = context.read<AppState>();
                        if (user == null) {
                          app.addUser(item);
                        } else {
                          app.updateUser(item);
                        }
                        Navigator.pop(context);
                      },
                      child: Text(user == null ? 'Save user' : 'Update user'),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  );
}

String _machineStatusText(MachineStatus status) => switch (status) {
      MachineStatus.running => 'Running',
      MachineStatus.maintenance => 'Maintenance',
      MachineStatus.fault => 'Fault',
      MachineStatus.stopped => 'Stopped',
      MachineStatus.offline => 'Offline',
    };
