import '../models/app_user.dart';

List<AppUser> buildSeedUsers() => const <AppUser>[
  AppUser(
    id: 'u-01',
    name: 'Belal Saqer',
    email: 'belal19lol@gmail.com',
    role: AppRole.admin,
    assignedArea: 'Main Factory',
    enabled: true,
  ),
  AppUser(
    id: 'u-02',
    name: 'Alaa Operator',
    email: 'alaa@factory.local',
    role: AppRole.operator,
    assignedArea: 'Hall A',
    enabled: true,
  ),
  AppUser(
    id: 'u-03',
    name: 'Mariam Maintenance',
    email: 'mariam@factory.local',
    role: AppRole.maintenance,
    assignedArea: 'Hall B',
    enabled: true,
  ),
  AppUser(
    id: 'u-04',
    name: 'Observer View',
    email: 'viewer@factory.local',
    role: AppRole.viewer,
    assignedArea: 'Executive Floor',
    enabled: true,
  ),
];
