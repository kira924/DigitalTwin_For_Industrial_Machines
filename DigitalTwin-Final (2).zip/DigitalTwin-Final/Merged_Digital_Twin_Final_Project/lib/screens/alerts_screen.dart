import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app/state.dart';
import '../theme/dt_colors.dart';
import '../theme/dt_widgets.dart';

class AlertsScreen extends StatelessWidget {
  const AlertsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      appBar: appHeader(title: app.isArabic ? 'التنبيهات والإشعارات' : 'Alerts & Notifications', subtitle: app.isArabic ? 'الأحداث الحرجة وعتبات السلامة' : 'Critical events and safety thresholds'),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 110),
        children: [
          GlassCard(
            child: Column(children: [
              SwitchListTile.adaptive(value: app.notificationsEnabled, onChanged: (v) => context.read<AppState>().toggleNotifications(v), title: Text(app.isArabic ? 'إشعارات فورية' : 'Push notifications', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)), subtitle: Text(app.isArabic ? 'تنبيه عند ارتفاع الحرارة أو توقف الماكينة' : 'Notify when a machine goes down or overheats', style: TextStyle(color: DT.muted(0.55)))),
              SwitchListTile.adaptive(value: app.offlineMode, onChanged: (v) => context.read<AppState>().toggleOfflineMode(v), title: Text(app.isArabic ? 'الوضع دون اتصال' : 'Offline mode', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)), subtitle: Text(app.isArabic ? 'استخدم آخر حالة معروفة عند انقطاع الاتصال' : 'Use the last-known machine state when connectivity drops', style: TextStyle(color: DT.muted(0.55)))),
            ]),
          ),
          const SizedBox(height: 14),
          GlassCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(app.isArabic ? 'عتبات التنبيه' : 'Alert thresholds', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 22)),
              const SizedBox(height: 14),
              _ThresholdRow(label: app.isArabic ? 'الحرارة القصوى' : 'Max temperature', value: app.temperatureThreshold, max: 120, suffix: '°C', onChanged: (v) => context.read<AppState>().updateThresholds(temperature: v)),
              _ThresholdRow(label: app.isArabic ? 'اهتزاز خطر' : 'Vibration fault limit', value: app.vibrationThreshold, max: 1.2, suffix: 'mm/s', onChanged: (v) => context.read<AppState>().updateThresholds(vibration: v)),
              _ThresholdRow(label: app.isArabic ? 'الطاقة القصوى' : 'Power ceiling', value: app.powerThreshold, max: 40, suffix: 'kW', onChanged: (v) => context.read<AppState>().updateThresholds(power: v)),
            ]),
          ),
          const SizedBox(height: 14),
          ...app.alerts.map((alert) => Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: GlassCard(
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Container(width: 42, height: 42, decoration: BoxDecoration(color: alert.color.alphaF(0.12), borderRadius: BorderRadius.circular(14)), child: Icon(Icons.notification_important_rounded, color: alert.color)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(alert.title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(alert.message, style: TextStyle(color: DT.muted(0.62), fontWeight: FontWeight.w600)), const SizedBox(height: 6), Text('${alert.time.hour.toString().padLeft(2, '0')}:${alert.time.minute.toString().padLeft(2, '0')}', style: TextStyle(color: DT.muted(0.45), fontWeight: FontWeight.w600, fontSize: 12))]))]),
            ),
          )),
        ],
      ),
    );
  }
}

class _ThresholdRow extends StatelessWidget {
  final String label;
  final double value;
  final double max;
  final String suffix;
  final ValueChanged<double> onChanged;
  const _ThresholdRow({required this.label, required this.value, required this.max, required this.suffix, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)), Text('${value.toStringAsFixed(max <= 2 ? 2 : 0)} $suffix', style: TextStyle(color: DT.cyan, fontWeight: FontWeight.w800))]), Slider(value: value, max: max, onChanged: onChanged)]);
  }
}
