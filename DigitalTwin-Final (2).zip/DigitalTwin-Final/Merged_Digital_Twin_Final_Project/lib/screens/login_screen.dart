import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app/state.dart';
import '../models/app_user.dart';
import '../theme/dt_colors.dart';
import '../theme/dt_widgets.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController email = TextEditingController(text: 'belal19lol@gmail.com');
  final TextEditingController pass = TextEditingController(text: '123456');

  @override
  void dispose() {
    email.dispose();
    pass.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final app = context.read<AppState>();
    final error = await app.login(email: email.text, password: pass.text);
    if (!mounted || error == null) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(error)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF020617), Color(0xFF0B1220), Color(0xFF0B2940)],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 460),
                child: Column(
                  children: [
                    Container(
                      width: 88,
                      height: 88,
                      decoration: BoxDecoration(
                        gradient: DT.grad,
                        borderRadius: BorderRadius.circular(28),
                        boxShadow: [BoxShadow(color: DT.cyan.alphaF(0.25), blurRadius: 22, offset: const Offset(0, 12))],
                      ),
                      child: const Icon(Icons.factory_rounded, color: Colors.white, size: 42),
                    ),
                    const SizedBox(height: 18),
                    Text(app.isArabic ? 'منصة المصنع الذكي' : 'Smart Factory Control', style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 8),
                    Text(app.isArabic ? 'مراقبة لحظية • Firebase Auth • Firestore Sync' : 'Real-time monitoring • Firebase Auth • Firestore Sync', textAlign: TextAlign.center, style: TextStyle(color: DT.muted(0.65), fontWeight: FontWeight.w600)),
                    const SizedBox(height: 22),
                    GlassCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: app.firebaseEnabled ? DT.green.alphaF(0.10) : DT.yellow.alphaF(0.10),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: app.firebaseEnabled ? DT.green.alphaF(0.25) : DT.yellow.alphaF(0.25)),
                            ),
                            child: Row(
                              children: [
                                Icon(app.firebaseEnabled ? Icons.cloud_done_rounded : Icons.cloud_off_rounded, color: app.firebaseEnabled ? DT.green : DT.yellow),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    app.firebaseStatus,
                                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 14),
                          Text(app.isArabic ? 'البريد الإلكتروني' : 'Email', style: TextStyle(color: DT.muted(0.7), fontWeight: FontWeight.w700)),
                          const SizedBox(height: 8),
                          TextField(controller: email, decoration: const InputDecoration(prefixIcon: Icon(Icons.mail_rounded), hintText: 'name@factory.local')),
                          const SizedBox(height: 14),
                          Text(app.isArabic ? 'كلمة المرور' : 'Password', style: TextStyle(color: DT.muted(0.7), fontWeight: FontWeight.w700)),
                          const SizedBox(height: 8),
                          TextField(controller: pass, obscureText: true, decoration: const InputDecoration(prefixIcon: Icon(Icons.lock_rounded), hintText: '••••••')),
                          const SizedBox(height: 14),
                          Text(app.isArabic ? 'الدخول السريع بالأدوار' : 'Quick role preview', style: TextStyle(color: DT.muted(0.7), fontWeight: FontWeight.w700)),
                          const SizedBox(height: 10),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: AppRole.values.map((role) {
                              return ChoiceChip(
                                selected: app.currentUser.role == role,
                                onSelected: (_) => context.read<AppState>().switchRole(role),
                                label: Text(role.name.toUpperCase()),
                              );
                            }).toList(growable: false),
                          ),
                          const SizedBox(height: 14),
                          Text(
                            app.firebaseEnabled
                                ? (app.isArabic ? 'تسجيل الدخول سيستخدم Firebase Authentication مع مزامنة Firestore.' : 'Sign in uses Firebase Authentication and keeps machines/users synced with Firestore.')
                                : (app.isArabic ? 'الآن يعمل بوضع العرض التجريبي. أضف مفاتيح Firebase في firebase_options.dart للتفعيل.' : 'Currently running in demo mode. Paste your Firebase keys into firebase_options.dart to enable cloud mode.'),
                            style: TextStyle(color: DT.muted(0.58), fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    if (app.authBusy)
                      const Padding(
                        padding: EdgeInsets.only(bottom: 12),
                        child: CircularProgressIndicator(color: DT.cyan),
                      ),
                    GradientButton(
                      text: app.authBusy
                          ? (app.isArabic ? 'جاري الدخول...' : 'Signing in...')
                          : (app.isArabic ? 'دخول المنصة' : 'Enter Factory'),
                      icon: Icons.arrow_forward_rounded,
                      onTap: app.authBusy ? () {} : () { _submit(); },
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
