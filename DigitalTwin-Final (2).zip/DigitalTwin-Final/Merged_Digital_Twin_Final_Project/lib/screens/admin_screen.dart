import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app/state.dart';
import '../models/app_user.dart';
import '../models/machine.dart';
import '../theme/dt_colors.dart';
import '../theme/dt_widgets.dart';
import '../widgets/form_sheets.dart';

class AdminScreen extends StatelessWidget {
  const AdminScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    if (!app.isAdmin) {
      return Scaffold(
        appBar: appHeader(title: app.isArabic ? 'إعدادات المنصة' : 'Platform Settings', subtitle: app.isArabic ? 'الوصول مقيد للمشرفين' : 'Admin access required'),
        body: ListView(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 110),
          children: [
            GlassCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(app.isArabic ? 'عرض فقط لهذا الدور' : 'View-only for this role', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 24)),
                const SizedBox(height: 8),
                Text(app.isArabic ? 'بدّل الدور من شاشة الدخول أو اطلب صلاحية Admin لعرض إدارة المستخدمين والماكينات.' : 'Switch role from login or sign in as Admin to manage users, machines, and thresholds.', style: TextStyle(color: DT.muted(0.6), fontWeight: FontWeight.w600)),
                const SizedBox(height: 16),
                _CommonSettings(),
              ]),
            ),
          ],
        ),
      );
    }

    return Scaffold(
      appBar: appHeader(
        title: app.isArabic ? 'الإدارة والإعدادات' : 'Administration & Settings',
        subtitle: app.isArabic ? 'إدارة المستخدمين والماكينات والتنبيهات' : 'Manage users, machines, alerts, and app behavior',
        trailing: IconButton(
          onPressed: () => context.read<AppState>().logout(),
          icon: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: DT.red.alphaF(0.10), borderRadius: BorderRadius.circular(16), border: Border.all(color: DT.red.alphaF(0.22))),
            child: const Icon(Icons.logout_rounded, color: DT.red),
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 110),
        children: [
          _CommonSettings(),
          const SizedBox(height: 14),
          const _FirebasePanel(),
          const SizedBox(height: 14),
          _MachineAdminPanel(),
          const SizedBox(height: 14),
          _UserAdminPanel(),
        ],
      ),
    );
  }
}

class _CommonSettings extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return GlassCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(app.isArabic ? 'سلوك التطبيق' : 'App behavior', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 22)),
        const SizedBox(height: 12),
        SwitchListTile.adaptive(value: app.themeMode == ThemeMode.dark, onChanged: (v) => context.read<AppState>().toggleTheme(v), title: Text(app.isArabic ? 'الوضع الداكن' : 'Dark mode', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800))),
        SwitchListTile.adaptive(value: app.notificationsEnabled, onChanged: (v) => context.read<AppState>().toggleNotifications(v), title: Text(app.isArabic ? 'الإشعارات الحرجة' : 'Critical alerts', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800))),
        SwitchListTile.adaptive(value: app.offlineMode, onChanged: (v) => context.read<AppState>().toggleOfflineMode(v), title: Text(app.isArabic ? 'الوضع دون اتصال مع آخر حالة' : 'Offline mode with last-known status', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800))),
        const SizedBox(height: 8),
        Text(app.isArabic ? 'الأدوار' : 'Roles preview', style: TextStyle(color: DT.muted(0.58), fontWeight: FontWeight.w700)),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: AppRole.values.map((role) {
            return ChoiceChip(
              label: Text(role.name.toUpperCase()),
              selected: app.currentUser.role == role,
              onSelected: (_) => context.read<AppState>().switchRole(role),
            );
          }).toList(growable: false),
        ),
      ]),
    );
  }
}


class _FirebasePanel extends StatelessWidget {
  const _FirebasePanel();

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(app.firebaseEnabled ? Icons.cloud_done_rounded : Icons.cloud_off_rounded, color: app.firebaseEnabled ? DT.green : DT.yellow),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  app.isArabic ? 'حالة Firebase' : 'Firebase Status',
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 22),
                ),
              ),
              FilledButton.icon(
                onPressed: app.syncBusy ? null : () { context.read<AppState>().syncNow(); },
                icon: Icon(app.syncBusy ? Icons.hourglass_bottom_rounded : Icons.sync_rounded),
                label: Text(app.isArabic ? 'مزامنة الآن' : 'Sync Now'),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            app.firebaseStatus,
            style: TextStyle(color: DT.muted(0.62), fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: app.firebaseEnabled ? DT.green.alphaF(0.10) : DT.yellow.alphaF(0.10),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: app.firebaseEnabled ? DT.green.alphaF(0.20) : DT.yellow.alphaF(0.20)),
            ),
            child: Text(
              app.firebaseEnabled
                  ? (app.isArabic ? 'المستخدمون والماكينات والإعدادات ترتبط الآن مع Firestore.' : 'Machines, users, and settings are now wired to Firestore.')
                  : (app.isArabic ? 'أضف مفاتيح Firebase داخل lib/firebase/firebase_options.dart لتفعيل Firebase Auth وFirestore.' : 'Paste your real Firebase keys into lib/firebase/firebase_options.dart to enable Firebase Auth and Firestore.'),
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }
}

class _MachineAdminPanel extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return GlassCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(app.isArabic ? 'إدارة الماكينات' : 'Machine Management', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 22)),
          FilledButton.icon(onPressed: () => showMachineFormSheet(context), icon: const Icon(Icons.add_rounded), label: Text(app.isArabic ? 'إضافة ماكينة' : 'Add Machine')),
        ]),
        const SizedBox(height: 14),
        ...app.machines.map((machine) => Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: DT.surface(0.18), borderRadius: BorderRadius.circular(18), border: Border.all(color: DT.border(0.35))),
          child: Row(children: [ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.asset(machine.imagePath, width: 58, height: 58, fit: BoxFit.cover)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(machine.name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)), const SizedBox(height: 4), Text('${machine.code} • ${machine.location}', style: TextStyle(color: DT.muted(0.55), fontWeight: FontWeight.w600))])), IconButton(onPressed: () => showMachineFormSheet(context, machine: machine), icon: const Icon(Icons.edit_rounded, color: DT.cyan)), IconButton(onPressed: () => context.read<AppState>().deleteMachine(machine.id), icon: const Icon(Icons.delete_outline_rounded, color: DT.red))]),
        )),
      ]),
    );
  }
}

class _UserAdminPanel extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return GlassCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(app.isArabic ? 'إدارة المستخدمين' : 'User Management', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 22)), FilledButton.icon(onPressed: () => showUserFormSheet(context), icon: const Icon(Icons.person_add_alt_1_rounded), label: Text(app.isArabic ? 'إضافة مستخدم' : 'Add User'))]),
        const SizedBox(height: 14),
        ...app.users.map((user) => Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: DT.surface(0.18), borderRadius: BorderRadius.circular(18), border: Border.all(color: DT.border(0.35))),
          child: Row(children: [CircleAvatar(backgroundColor: DT.blue.alphaF(0.15), child: Text(user.name.characters.first.toUpperCase(), style: const TextStyle(color: DT.cyan))), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(user.name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)), const SizedBox(height: 4), Text('${user.email} • ${user.role.name}', style: TextStyle(color: DT.muted(0.55), fontWeight: FontWeight.w600))])), IconButton(onPressed: () => showUserFormSheet(context, user: user), icon: const Icon(Icons.edit_rounded, color: DT.cyan)), IconButton(onPressed: user.id == app.currentUser.id ? null : () => context.read<AppState>().deleteUser(user.id), icon: Icon(Icons.delete_outline_rounded, color: user.id == app.currentUser.id ? DT.dim(0.25) : DT.red))]),
        )),
      ]),
    );
  }
}
