import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app/state.dart';
import '../theme/dt_colors.dart';
import '../theme/dt_widgets.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      appBar: appHeader(title: app.isArabic ? 'السجل الزمني' : 'Activity History', subtitle: app.isArabic ? 'كل عمليات التشغيل والتنبيه والإدارة' : 'Machine, alert, and admin events'),
      body: ListView.separated(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 110),
        itemCount: app.history.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          final event = app.history[index];
          return GlassCard(
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Container(width: 46, height: 46, decoration: BoxDecoration(color: event.color.alphaF(0.12), borderRadius: BorderRadius.circular(16)), child: Icon(event.icon, color: event.color)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(event.title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(event.subtitle, style: TextStyle(color: DT.muted(0.60), fontWeight: FontWeight.w600)), const SizedBox(height: 6), Text('${event.time.hour.toString().padLeft(2, '0')}:${event.time.minute.toString().padLeft(2, '0')} • ${event.time.day}/${event.time.month}/${event.time.year}', style: TextStyle(color: DT.muted(0.45), fontWeight: FontWeight.w600, fontSize: 12))]))]),
          );
        },
      ),
    );
  }
}
