import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app/state.dart';
import '../models/machine.dart';
import '../theme/dt_colors.dart';
import '../theme/dt_widgets.dart';
import '../widgets/form_sheets.dart';

class MachineListScreen extends StatefulWidget {
  const MachineListScreen({super.key});

  @override
  State<MachineListScreen> createState() => _MachineListScreenState();
}

class _MachineListScreenState extends State<MachineListScreen> {
  String query = '';
  MachineStatus? filter;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final list = app.machines.where((machine) {
      final matchQuery = query.isEmpty || machine.name.toLowerCase().contains(query.toLowerCase()) || machine.code.toLowerCase().contains(query.toLowerCase()) || machine.type.toLowerCase().contains(query.toLowerCase());
      final matchFilter = filter == null || machine.status == filter;
      return matchQuery && matchFilter;
    }).toList(growable: false);

    return Scaffold(
      floatingActionButton: app.isAdmin
          ? FloatingActionButton(
              onPressed: () => showMachineFormSheet(context),
              backgroundColor: DT.cyan.alphaF(0.16),
              foregroundColor: DT.cyan,
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
                side: BorderSide(color: DT.cyan.alphaF(0.28)),
              ),
              child: const Icon(Icons.add_rounded),
            )
          : null,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 110),
          children: [
            Row(
            children: [
              Expanded(child: _MiniStat(label: app.isArabic ? 'تشغيل' : 'Running', value: '${app.runningCount}', color: DT.green)),
              const SizedBox(width: 10),
              Expanded(child: _MiniStat(label: app.isArabic ? 'صيانة' : 'Maintenance', value: '${app.maintenanceCount}', color: DT.yellow)),
              const SizedBox(width: 10),
              Expanded(child: _MiniStat(label: app.isArabic ? 'أعطال' : 'Faults', value: '${app.faultCount}', color: DT.red)),
            ],
          ),
          const SizedBox(height: 12),
          GlassCard(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            child: Row(
              children: [
                Icon(Icons.search_rounded, color: DT.dim(0.55)),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: app.isArabic ? 'ابحث باسم الماكينة أو المعرف' : 'Search by machine name or code',
                      border: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      filled: false,
                    ),
                    onChanged: (value) => setState(() => query = value),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _FilterChip(label: app.isArabic ? 'الكل' : 'All', active: filter == null, onTap: () => setState(() => filter = null)),
                _FilterChip(label: app.isArabic ? 'تشغيل' : 'Running', active: filter == MachineStatus.running, onTap: () => setState(() => filter = MachineStatus.running)),
                _FilterChip(label: app.isArabic ? 'صيانة' : 'Maintenance', active: filter == MachineStatus.maintenance, onTap: () => setState(() => filter = MachineStatus.maintenance)),
                _FilterChip(label: app.isArabic ? 'عطل' : 'Fault', active: filter == MachineStatus.fault, onTap: () => setState(() => filter = MachineStatus.fault)),
                _FilterChip(label: app.isArabic ? 'متوقفة' : 'Stopped', active: filter == MachineStatus.stopped, onTap: () => setState(() => filter = MachineStatus.stopped)),
              ],
            ),
          ),
          const SizedBox(height: 14),
            LayoutBuilder(
              builder: (context, constraints) {
                final width = constraints.maxWidth;
                final crossAxisCount = width > 1000 ? 3 : width > 640 ? 2 : 1;
                final ratio = width > 640 ? 0.94 : 1.03;
                return GridView.builder(
                  itemCount: list.length,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: crossAxisCount,
                    mainAxisSpacing: 14,
                    crossAxisSpacing: 14,
                    childAspectRatio: ratio,
                  ),
                  itemBuilder: (context, index) => _MachineCard(machine: list[index]),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _FactoryHero extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: Stack(
        children: [
          Image.asset('assets/images/factory_hero.png', height: 190, width: double.infinity, fit: BoxFit.cover),
          Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.black.alphaF(0.08), Colors.black.alphaF(0.66)])))),
        ],
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _MiniStat({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: TextStyle(color: DT.muted(0.6), fontWeight: FontWeight.w700)),
        const SizedBox(height: 10),
        Text(value, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 22)),
      ]),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;
  const _FilterChip({required this.label, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(label: Text(label), selected: active, onSelected: (_) => onTap()),
    );
  }
}

class _MachineCard extends StatelessWidget {
  final Machine machine;
  const _MachineCard({required this.machine});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final color = statusColor(machine.status);
    final statusLabel = statusText(machine.status, app.isArabic);
    return InkWell(
      borderRadius: BorderRadius.circular(26),
      onTap: () => context.read<AppState>().openMachineDetail(machine.id),
      child: GlassCard(
        padding: EdgeInsets.zero,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(26)),
              child: Stack(
                children: [
                  Image.asset(machine.imagePath, height: 150, width: double.infinity, fit: BoxFit.cover),
                  Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black.alphaF(0.78)])))),
                  Positioned(top: 12, right: 12, child: _StatusBadge(label: statusLabel, color: color)),
                  if (machine.activeAlert != null)
                    Positioned(left: 12, right: 12, bottom: 12, child: Text(machine.activeAlert!, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700))),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(machine.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Colors.white)),
                const SizedBox(height: 4),
                Text(machine.code, style: TextStyle(color: DT.muted(0.58), fontWeight: FontWeight.w700)),
                const SizedBox(height: 12),
                Row(children: [Expanded(child: _MetricTile(label: app.isArabic ? 'الإنتاج' : 'Output', value: '${machine.productionRate.toStringAsFixed(0)}%', color: color)), const SizedBox(width: 10), Expanded(child: _MetricTile(label: app.isArabic ? 'الطاقة' : 'Power', value: '${machine.power.toStringAsFixed(1)} kW', color: DT.cyan))]),
                const SizedBox(height: 10),
                Row(children: [Icon(Icons.schedule_rounded, size: 16, color: DT.muted(0.45)), const SizedBox(width: 6), Expanded(child: Text('${app.isArabic ? 'آخر تحديث' : 'Updated'} ${timeAgo(machine.lastUpdated, app.isArabic)}', style: TextStyle(color: DT.muted(0.5), fontSize: 12, fontWeight: FontWeight.w600)))]),
              ]),
            ),
          ],
        ),
      ),
    );
  }
}

class _MetricTile extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _MetricTile({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: color.alphaF(0.10), borderRadius: BorderRadius.circular(18), border: Border.all(color: color.alphaF(0.20))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: TextStyle(color: DT.muted(0.58), fontSize: 12, fontWeight: FontWeight.w600)),
        const SizedBox(height: 10),
        Text(value, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 18)),
      ]),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final String label;
  final Color color;
  const _StatusBadge({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(color: color.alphaF(0.14), borderRadius: BorderRadius.circular(14), border: Border.all(color: color.alphaF(0.25))),
      child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.circle, size: 10, color: color), const SizedBox(width: 8), Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w800))]),
    );
  }
}

Color statusColor(MachineStatus status) => switch (status) {
      MachineStatus.running => DT.green,
      MachineStatus.maintenance => DT.yellow,
      MachineStatus.fault => DT.red,
      MachineStatus.stopped => DT.purple,
      MachineStatus.offline => DT.blue,
    };

String statusText(MachineStatus status, bool arabic) => switch (status) {
      MachineStatus.running => arabic ? 'تعمل' : 'Running',
      MachineStatus.maintenance => arabic ? 'صيانة' : 'Maintenance',
      MachineStatus.fault => arabic ? 'عطل' : 'Fault',
      MachineStatus.stopped => arabic ? 'متوقفة' : 'Stopped',
      MachineStatus.offline => arabic ? 'غير متصلة' : 'Offline',
    };

String timeAgo(DateTime value, bool arabic) {
  final diff = DateTime.now().difference(value);
  if (diff.inMinutes < 1) return arabic ? 'الآن' : 'just now';
  if (diff.inMinutes < 60) return arabic ? 'منذ ${diff.inMinutes} دقيقة' : '${diff.inMinutes} min ago';
  return arabic ? 'منذ ${diff.inHours} ساعة' : '${diff.inHours} h ago';
}
