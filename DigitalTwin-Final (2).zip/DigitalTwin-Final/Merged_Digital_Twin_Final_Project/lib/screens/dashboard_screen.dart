import 'dart:async';
import 'dart:math';

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app/state.dart';
import '../models/engine_telemetry_payload.dart';
import '../models/machine.dart';
import '../services/mqtt_service.dart';
import '../theme/dt_colors.dart';
import '../theme/dt_widgets.dart';
import '../widgets/charts.dart';
import '../widgets/form_sheets.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final MqttService _mqtt = MqttService();
  StreamSubscription<EngineTelemetryPayload>? _sub;
  final Map<int, EngineTelemetryPayload> _latestByEngine = <int, EngineTelemetryPayload>{};
  final Map<int, Map<String, List<double>>> _historyByEngine = <int, Map<String, List<double>>>{};
  String _status = 'Connecting to MQTT...';

  @override
  void initState() {
    super.initState();
    _sub = _mqtt.telemetryStream.listen((payload) {
      if (!mounted) return;
      setState(() {
        _latestByEngine[payload.engineId] = payload;
        _status = 'Live telemetry connected';
        final engineHistory = _historyByEngine.putIfAbsent(payload.engineId, () => <String, List<double>>{});
        payload.currentSensorReadings.forEach((key, value) {
          final list = engineHistory.putIfAbsent(key, () => <double>[]);
          list.add(value);
          if (list.length > 20) {
            list.removeRange(0, list.length - 20);
          }
        });
      });
    });
    _mqtt.connect().then((_) {
      if (!mounted) return;
      setState(() {
        _status = _mqtt.isConnected ? 'Waiting for machine telemetry...' : 'MQTT connection failed';
      });
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    _mqtt.dispose();
    super.dispose();
  }

  int _engineIdForMachine(Machine machine, List<Machine> machines) {
    final idx = machines.indexWhere((m) => m.id == machine.id);
    return idx >= 0 ? idx + 1 : 0;
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final selected = app.selectedMachineOrNull;
    return selected == null
        ? _FactoryDashboardView(
            mqttStatus: _status,
            latestByEngine: _latestByEngine,
            engineIdForMachine: (machine) => _engineIdForMachine(machine, app.machines),
          )
        : _MachineDashboardView(
            machine: selected,
            engineId: _engineIdForMachine(selected, app.machines),
            payload: _latestByEngine[_engineIdForMachine(selected, app.machines)],
            history: _historyByEngine[_engineIdForMachine(selected, app.machines)] ?? const <String, List<double>>{},
            mqttStatus: _status,
          );
  }
}

class _FactoryDashboardView extends StatelessWidget {
  const _FactoryDashboardView({
    required this.mqttStatus,
    required this.latestByEngine,
    required this.engineIdForMachine,
  });

  final String mqttStatus;
  final Map<int, EngineTelemetryPayload> latestByEngine;
  final int Function(Machine machine) engineIdForMachine;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final liveCount = app.machines.where((m) => latestByEngine.containsKey(engineIdForMachine(m))).length;
    return Scaffold(
      appBar: appHeader(
        title: 'Factory Dashboard',
        subtitle: 'Same realtime dashboard structure across all machines',
        trailing: _Pill(
          text: liveCount == 0 ? 'Waiting' : '$liveCount Live',
          color: liveCount == 0 ? DT.yellow : DT.green,
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 110),
        children: [
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Realtime Factory Overview',
                  style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 8),
                Text(
                  'Each machine card waits for its own data and updates independently.',
                  style: TextStyle(color: DT.muted(0.55), fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 10),
                Text(mqttStatus, style: TextStyle(color: DT.muted(0.48), fontWeight: FontWeight.w600)),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              SizedBox(width: 220, child: _KpiCard(label: 'Machines', value: '${app.machines.length}', note: 'Total monitored assets', color: DT.blue)),
              SizedBox(width: 220, child: _KpiCard(label: 'Running', value: '${app.runningCount}', note: 'Currently operating', color: DT.green)),
              SizedBox(width: 220, child: _KpiCard(label: 'Faults', value: '${app.faultCount}', note: 'Require attention', color: DT.red)),
              SizedBox(width: 220, child: _KpiCard(label: 'Live feeds', value: '$liveCount', note: 'Machines receiving telemetry', color: DT.cyan)),
            ],
          ),
          const SizedBox(height: 14),
          LayoutBuilder(
            builder: (context, constraints) {
              final width = constraints.maxWidth;
              final crossAxisCount = width > 1100 ? 3 : width > 720 ? 2 : 1;
              return GridView.builder(
                itemCount: app.machines.length,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: crossAxisCount,
                  mainAxisSpacing: 14,
                  crossAxisSpacing: 14,
                  childAspectRatio: width > 720 ? 1.07 : 1.03,
                ),
                itemBuilder: (context, index) {
                  final machine = app.machines[index];
                  final engineId = engineIdForMachine(machine);
                  final payload = latestByEngine[engineId];
                  return _FactoryMachineRealtimeCard(
                    machine: machine,
                    engineId: engineId,
                    payload: payload,
                  );
                },
              );
            },
          ),
        ],
      ),
    );
  }
}

class _FactoryMachineRealtimeCard extends StatelessWidget {
  const _FactoryMachineRealtimeCard({
    required this.machine,
    required this.engineId,
    required this.payload,
  });

  final Machine machine;
  final int engineId;
  final EngineTelemetryPayload? payload;

  @override
  Widget build(BuildContext context) {
    final color = statusColor(machine.status);
    final app = context.watch<AppState>();
    final live = payload != null;
    final temp = payload?.currentSensorReadings['s2'] ?? machine.temperature;
    final vib = payload?.currentSensorReadings['s12'] ?? machine.vibration;
    final rul = payload?.predictedRul;
    final cycle = payload?.currentCycle;
    return InkWell(
      borderRadius: BorderRadius.circular(26),
      onTap: () => context.read<AppState>().openMachineDetail(machine.id),
      child: GlassCard(
        padding: EdgeInsets.zero,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(26)),
              child: Stack(
                children: [
                  Image.asset(machine.imagePath, height: 140, width: double.infinity, fit: BoxFit.cover),
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Colors.transparent, Colors.black.alphaF(0.78)],
                        ),
                      ),
                    ),
                  ),
                  Positioned(top: 12, right: 12, child: _Pill(text: live ? 'Live' : 'Waiting', color: live ? DT.green : DT.yellow)),
                  Positioned(left: 12, right: 12, bottom: 12, child: Text(machine.name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 20))),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(child: Text('${machine.code} • Engine $engineId', style: TextStyle(color: DT.muted(0.58), fontWeight: FontWeight.w700))),
                      _Pill(text: statusText(machine.status, false), color: color),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(child: _MetricTile(label: 'Temperature', value: '${temp.toStringAsFixed(1)} °C', color: DT.red)),
                      const SizedBox(width: 10),
                      Expanded(child: _MetricTile(label: 'Vibration', value: vib.toStringAsFixed(2), color: DT.yellow)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(child: _MetricTile(label: 'Cycle', value: cycle?.toString() ?? '--', color: DT.cyan)),
                      const SizedBox(width: 10),
                      Expanded(child: _MetricTile(label: 'RUL', value: rul == null ? '--' : rul!.toStringAsFixed(0), color: rul == null ? DT.blue : _rulColor(rul!))),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    live ? 'Receiving machine-specific telemetry' : 'Waiting for data for this machine',
                    style: TextStyle(color: DT.muted(0.5), fontSize: 12, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MachineDashboardView extends StatelessWidget {
  const _MachineDashboardView({
    required this.machine,
    required this.engineId,
    required this.payload,
    required this.history,
    required this.mqttStatus,
  });

  final Machine machine;
  final int engineId;
  final EngineTelemetryPayload? payload;
  final Map<String, List<double>> history;
  final String mqttStatus;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final isLive = payload != null;
    final statusLabel = statusText(machine.status, false);
    final statusColorValue = statusColor(machine.status);
    final sensorMap = payload?.currentSensorReadings ?? <String, double>{};
    final rootCauses = payload?.aiRootCauses ?? const <String, double>{};
    final rul = payload?.predictedRul;
    final cycle = payload?.currentCycle;

    return Scaffold(
      appBar: appHeader(
        title: machine.name,
        subtitle: '${machine.code} • Engine $engineId',
        leading: InkWell(
          onTap: () => context.read<AppState>().backToMachines(),
          borderRadius: BorderRadius.circular(14),
          child: Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(color: Colors.white.alphaF(0.08), borderRadius: BorderRadius.circular(14), border: Border.all(color: DT.border(0.35))),
            child: const Icon(Icons.arrow_back_rounded, color: Colors.white),
          ),
        ),
        trailing: _Pill(text: isLive ? 'Live' : 'Waiting', color: isLive ? DT.green : DT.yellow),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 110),
        children: [
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Machine Realtime Dashboard', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
                          const SizedBox(height: 8),
                          Text('Same design and structure as the factory dashboard, scoped to this machine only.', style: TextStyle(color: DT.muted(0.55), fontWeight: FontWeight.w600)),
                          const SizedBox(height: 8),
                          Text(isLive ? 'Receiving live telemetry for this machine' : mqttStatus, style: TextStyle(color: DT.muted(0.48), fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ),
                    _Pill(text: statusLabel, color: statusColorValue),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              SizedBox(width: 220, child: _KpiCard(label: 'Engine ID', value: '$engineId', note: 'Mapped machine feed', color: DT.blue)),
              SizedBox(width: 220, child: _KpiCard(label: 'Current Cycle', value: cycle?.toString() ?? '--', note: 'Latest telemetry cycle', color: DT.cyan)),
              SizedBox(width: 220, child: _KpiCard(label: 'Predicted RUL', value: rul == null ? '--' : rul!.toStringAsFixed(0), note: 'Remaining useful life', color: rul == null ? DT.blue : _rulColor(rul!))),
              SizedBox(width: 220, child: _KpiCard(label: 'Machine Status', value: statusLabel, note: machine.activeAlert ?? 'No active alert', color: statusColorValue)),
            ],
          ),
          const SizedBox(height: 14),
          if (!isLive)
            GlassCard(
              child: SizedBox(
                height: 180,
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      CircularProgressIndicator(color: DT.cyan),
                      SizedBox(height: 12),
                      Text('Waiting for this machine data...', style: TextStyle(color: Colors.white70)),
                    ],
                  ),
                ),
              ),
            )
          else ...[
            GlassCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Sensors Overview', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 22)),
                  const SizedBox(height: 14),
                  Wrap(
                    spacing: 12,
                    runSpacing: 12,
                    children: sensorMap.entries.take(6).map((entry) {
                      return SizedBox(
                        width: 220,
                        child: _SensorMiniCard(
                          sensorName: entry.key,
                          sensorValue: entry.value,
                          history: history[entry.key] ?? const <double>[],
                        ),
                      );
                    }).toList(growable: false),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            GlassCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('AI Root Causes', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 22)),
                  const SizedBox(height: 16),
                  SizedBox(height: 260, child: _RootCauseChart(causes: rootCauses)),
                ],
              ),
            ),
            const SizedBox(height: 14),
          ],
          GlassCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Performance Trend', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 22)),
                const SizedBox(height: 12),
                SizedBox(
                  height: 220,
                  child: AreaChart(
                    points: machine.performanceSeries.map((p) => DTPoint(p.label, p.value)).toList(growable: false),
                    minY: 40,
                    maxY: 100,
                    lineColor: DT.cyan,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Text('Quick Actions', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 24)),
          const SizedBox(height: 12),
          _ActionButton(label: 'Report Issue', color: DT.red, icon: Icons.report_gmailerrorred_rounded, onTap: () => context.read<AppState>().reportIssue(machine.id)),
          const SizedBox(height: 10),
          _ActionButton(label: 'Schedule Maintenance', color: DT.yellow, icon: Icons.build_circle_rounded, onTap: () => context.read<AppState>().requestMaintenance(machine.id)),
          const SizedBox(height: 10),
          _ActionButton(
            label: machine.status == MachineStatus.running ? 'Stop Machine' : 'Start Machine',
            color: machine.status == MachineStatus.running ? DT.purple : DT.green,
            icon: machine.status == MachineStatus.running ? Icons.pause_circle_rounded : Icons.play_circle_rounded,
            onTap: () => machine.status == MachineStatus.running ? context.read<AppState>().stopMachine(machine.id) : context.read<AppState>().startMachine(machine.id),
          ),
          if (app.isAdmin) ...[
            const SizedBox(height: 10),
            _ActionButton(label: 'Edit Machine', color: DT.blue, icon: Icons.edit_rounded, onTap: () => showMachineFormSheet(context, machine: machine)),
          ],
        ],
      ),
    );
  }
}

class _RootCauseChart extends StatelessWidget {
  const _RootCauseChart({required this.causes});
  final Map<String, double> causes;

  @override
  Widget build(BuildContext context) {
    final entries = causes.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final topThree = entries.take(3).toList(growable: false);
    if (topThree.isEmpty) {
      return const Center(child: Text('No AI explanation data yet', style: TextStyle(color: Colors.white70)));
    }
    final maxY = (topThree.map((e) => e.value).reduce(max) * 1.2).clamp(5, 1000).toDouble();
    return BarChart(
      BarChartData(
        alignment: BarChartAlignment.spaceAround,
        maxY: maxY,
        titlesData: FlTitlesData(
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 36,
              interval: max(1, maxY / 5),
              getTitlesWidget: (value, meta) => Text(value.toStringAsFixed(0), style: const TextStyle(color: Color(0xFF8FA2B8), fontSize: 11)),
            ),
          ),
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (value, meta) {
                final index = value.toInt();
                if (index < 0 || index >= topThree.length) return const SizedBox.shrink();
                return Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(topThree[index].key, style: const TextStyle(color: Color(0xFF8FA2B8), fontSize: 12, fontWeight: FontWeight.w600)),
                );
              },
            ),
          ),
        ),
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          getDrawingHorizontalLine: (value) => const FlLine(color: Color(0xFF233447), strokeWidth: 1),
        ),
        borderData: FlBorderData(show: false),
        barGroups: List<BarChartGroupData>.generate(topThree.length, (index) {
          final entry = topThree[index];
          return BarChartGroupData(
            x: index,
            barRods: [
              BarChartRodData(
                toY: entry.value,
                width: 28,
                borderRadius: BorderRadius.circular(8),
                gradient: const LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFFFFA24C), Color(0xFFFF5A5A)],
                ),
              ),
            ],
          );
        }),
      ),
    );
  }
}

class _SensorMiniCard extends StatelessWidget {
  const _SensorMiniCard({
    required this.sensorName,
    required this.sensorValue,
    required this.history,
  });

  final String sensorName;
  final double sensorValue;
  final List<double> history;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(sensorName.toUpperCase(), style: const TextStyle(color: Color(0xFF8FA2B8), fontSize: 11, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Text(sensorValue.toStringAsFixed(4), style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          SizedBox(height: 44, child: _SensorSparkline(history: history)),
        ],
      ),
    );
  }
}

class _SensorSparkline extends StatelessWidget {
  const _SensorSparkline({required this.history});
  final List<double> history;

  @override
  Widget build(BuildContext context) {
    if (history.length < 2) {
      return Center(child: Text('No trend yet', style: TextStyle(color: DT.muted(0.45), fontSize: 11)));
    }
    final spots = List<FlSpot>.generate(history.length, (i) => FlSpot(i.toDouble(), history[i]));
    final minY = spots.map((p) => p.y).reduce(min) - 0.01;
    final maxY = spots.map((p) => p.y).reduce(max) + 0.01;
    return LineChart(
      LineChartData(
        minX: 0,
        maxX: (spots.length - 1).toDouble(),
        minY: minY,
        maxY: maxY,
        lineBarsData: [
          LineChartBarData(
            spots: spots,
            isCurved: true,
            curveSmoothness: 0.28,
            barWidth: 2.2,
            color: const Color(0xFF6BD7FF),
            isStrokeCapRound: true,
            dotData: const FlDotData(show: false),
            belowBarData: BarAreaData(
              show: true,
              gradient: const LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0x886BD7FF), Color(0x006BD7FF)],
              ),
            ),
          ),
        ],
        gridData: const FlGridData(show: false),
        borderData: FlBorderData(show: false),
        titlesData: const FlTitlesData(
          leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
          topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
          bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        lineTouchData: const LineTouchData(enabled: false),
      ),
    );
  }
}

class _KpiCard extends StatelessWidget {
  const _KpiCard({required this.label, required this.value, required this.note, required this.color});

  final String label;
  final String value;
  final String note;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(color: DT.muted(0.58), fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Text(value, style: TextStyle(color: color, fontSize: 28, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Text(note, style: TextStyle(color: DT.muted(0.52), fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}

class _MetricTile extends StatelessWidget {
  const _MetricTile({required this.label, required this.value, required this.color});

  final String label;
  final String value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.alphaF(0.10),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: color.alphaF(0.20)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(color: DT.muted(0.58), fontSize: 12, fontWeight: FontWeight.w600)),
          const SizedBox(height: 10),
          Text(value, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 18)),
        ],
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  const _Pill({required this.text, required this.color});
  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: color.alphaF(0.10),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.alphaF(0.25)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.circle, size: 10, color: color),
          const SizedBox(width: 8),
          Text(text, style: TextStyle(color: color, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  const _ActionButton({required this.label, required this.color, required this.icon, required this.onTap});

  final String label;
  final Color color;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton.icon(
        onPressed: onTap,
        icon: Icon(icon, color: color),
        label: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w800)),
        ),
        style: OutlinedButton.styleFrom(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          side: BorderSide(color: color.alphaF(0.35)),
          backgroundColor: color.alphaF(0.08),
        ),
      ),
    );
  }
}

Color _rulColor(double rul) {
  if (rul < 50) return DT.red;
  if (rul < 100) return const Color(0xFFFFB74D);
  return DT.green;
}

Color statusColor(MachineStatus status) => switch (status) {
      MachineStatus.running => DT.green,
      MachineStatus.maintenance => DT.yellow,
      MachineStatus.fault => DT.red,
      MachineStatus.stopped => DT.purple,
      MachineStatus.offline => DT.blue,
    };

String statusText(MachineStatus status, bool arabic) => switch (status) {
      MachineStatus.running => arabic ? 'تعمل' : 'Running',
      MachineStatus.maintenance => arabic ? 'صيانة' : 'Maintenance',
      MachineStatus.fault => arabic ? 'عطل' : 'Fault',
      MachineStatus.stopped => arabic ? 'متوقفة' : 'Stopped',
      MachineStatus.offline => arabic ? 'غير متصلة' : 'Offline',
    };
