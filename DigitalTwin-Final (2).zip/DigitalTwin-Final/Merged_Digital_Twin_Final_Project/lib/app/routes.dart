import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../screens/admin_screen.dart';
import '../screens/alerts_screen.dart';
import '../screens/dashboard_screen.dart';
import '../screens/history_screen.dart';
import '../screens/machines_screen.dart';
import '../theme/dt_colors.dart';
import 'state.dart';

class AppShell extends StatelessWidget {
  const AppShell({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final screen = switch (app.currentTab) {
      AppTab.machines => const MachineListScreen(),
      AppTab.dashboard => const DashboardScreen(),
      AppTab.alerts => const AlertsScreen(),
      AppTab.history => const HistoryScreen(),
      AppTab.admin => const AdminScreen(),
    };

    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(child: screen),
          const Positioned(left: 0, right: 0, bottom: 0, child: _BottomNav()),
        ],
      ),
    );
  }
}

class _BottomNav extends StatelessWidget {
  const _BottomNav();

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final items = <({AppTab tab, IconData icon, String label})>[
      (tab: AppTab.machines, icon: Icons.precision_manufacturing_rounded, label: app.isArabic ? 'الماكينات' : 'Machines'),
      (tab: AppTab.dashboard, icon: Icons.dashboard_rounded, label: app.isArabic ? 'المصنع' : 'Dashboard'),
      (tab: AppTab.alerts, icon: Icons.notifications_active_rounded, label: app.isArabic ? 'التنبيهات' : 'Alerts'),
      (tab: AppTab.history, icon: Icons.history_rounded, label: app.isArabic ? 'السجل' : 'History'),
      (tab: AppTab.admin, icon: Icons.admin_panel_settings_rounded, label: app.isArabic ? 'الإدارة' : 'Admin'),
    ];

    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
        decoration: BoxDecoration(
          color: app.themeMode == ThemeMode.dark ? const Color(0xFF07111F) : Colors.white,
          border: Border(top: BorderSide(color: DT.border(0.35))),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 18, offset: const Offset(0, -6))],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: items.map((item) {
            final active = app.currentTab == item.tab;
            final color = active ? DT.cyan : (app.themeMode == ThemeMode.dark ? DT.dim(0.5) : Colors.black54);
            return InkWell(
              onTap: () => context.read<AppState>().setTab(item.tab),
              borderRadius: BorderRadius.circular(16),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(item.icon, color: color),
                    const SizedBox(height: 3),
                    Text(item.label, style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 11)),
                  ],
                ),
              ),
            );
          }).toList(growable: false),
        ),
      ),
    );
  }
}
