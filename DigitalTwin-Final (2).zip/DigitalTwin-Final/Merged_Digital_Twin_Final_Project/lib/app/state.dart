import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/machine_catalog.dart';
import '../data/user_catalog.dart';
import '../firebase/firebase_bootstrap.dart';
import '../models/app_user.dart';
import '../models/machine.dart';
import '../services/firebase_sync_service.dart';
import '../theme/dt_colors.dart';

enum AppTab { machines, dashboard, alerts, history, admin }
enum DashboardRange { day, week, month, quarter, year, custom }

class AppAlert {
  final String id;
  final String machineId;
  final String title;
  final String message;
  final DateTime time;
  final Color color;

  const AppAlert({
    required this.id,
    required this.machineId,
    required this.title,
    required this.message,
    required this.time,
    required this.color,
  });
}

class HistoryLog {
  final String id;
  final DateTime time;
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;

  const HistoryLog({
    required this.id,
    required this.time,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
  });
}

class AppState extends ChangeNotifier {
  bool _isLoggedIn = false;
  bool get isLoggedIn => _isLoggedIn;

  bool _isBootstrapping = true;
  bool get isBootstrapping => _isBootstrapping;

  bool _authBusy = false;
  bool get authBusy => _authBusy;

  bool _firebaseEnabled = false;
  bool get firebaseEnabled => _firebaseEnabled;

  bool _syncBusy = false;
  bool get syncBusy => _syncBusy;

  String _firebaseStatus = 'Initializing app state...';
  String get firebaseStatus => _firebaseStatus;

  AppTab _currentTab = AppTab.machines;
  AppTab get currentTab => _currentTab;

  ThemeMode _themeMode = ThemeMode.dark;
  ThemeMode get themeMode => _themeMode;

  bool _isArabic = false;
  bool get isArabic => _isArabic;

  bool _notificationsEnabled = true;
  bool get notificationsEnabled => _notificationsEnabled;

  bool _offlineMode = true;
  bool get offlineMode => _offlineMode;

  DashboardRange _range = DashboardRange.day;
  DashboardRange get range => _range;

  String? _selectedMachineId;
  String? get selectedMachineId => _selectedMachineId;

  late List<Machine> _machines;
  List<Machine> get machines => List<Machine>.unmodifiable(_machines);

  late List<AppUser> _users;
  List<AppUser> get users => List<AppUser>.unmodifiable(_users);

  late AppUser _currentUser;
  AppUser get currentUser => _currentUser;
  bool get isAdmin => _currentUser.role == AppRole.admin;

  double temperatureThreshold = 80;
  double vibrationThreshold = 0.65;
  double powerThreshold = 28;

  final List<AppAlert> _alerts = <AppAlert>[];
  List<AppAlert> get alerts => List<AppAlert>.unmodifiable(_alerts);

  final List<HistoryLog> _history = <HistoryLog>[];
  List<HistoryLog> get history => List<HistoryLog>.unmodifiable(_history);

  Timer? _simulator;
  final Random _random = Random(7);
  SharedPreferences? _prefs;
  FirebaseSyncService? _firebase;
  StreamSubscription<List<Machine>>? _machineSubscription;
  StreamSubscription<List<AppUser>>? _userSubscription;

  AppState() {
    _machines = buildSeedMachines();
    _users = buildSeedUsers();
    _currentUser = _users.first;
    _seedLogs();
    _initialize();
  }

  Machine? get selectedMachineOrNull {
    final id = _selectedMachineId;
    if (id == null) return null;
    for (final machine in _machines) {
      if (machine.id == id) return machine;
    }
    return null;
  }

  int get runningCount => _machines.where((m) => m.status == MachineStatus.running).length;
  int get maintenanceCount => _machines.where((m) => m.status == MachineStatus.maintenance).length;
  int get stoppedCount => _machines.where((m) => m.status == MachineStatus.stopped).length;
  int get faultCount => _machines.where((m) => m.status == MachineStatus.fault).length;

  double get overallOee {
    if (_machines.isEmpty) return 0;
    final total = _machines.fold<int>(0, (sum, machine) => sum + machine.efficiency);
    return total / _machines.length;
  }

  double get energyConsumption => _machines.fold<double>(0, (sum, machine) => sum + machine.power) * _rangeMultiplier;
  double get operatingHours => runningCount * 8.4 * _rangeMultiplier;
  double get downtimeHours => (maintenanceCount * 2.2 + stoppedCount * 3.4 + faultCount * 5.1) * _rangeMultiplier;
  int get productionOutput => _machines.fold<int>(0, (sum, machine) => sum + machine.productionCount);

  double get _rangeMultiplier {
    switch (_range) {
      case DashboardRange.day:
        return 1;
      case DashboardRange.week:
        return 7;
      case DashboardRange.month:
        return 30;
      case DashboardRange.quarter:
        return 90;
      case DashboardRange.year:
        return 365;
      case DashboardRange.custom:
        return 14;
    }
  }

  List<MachineMetricPoint> get factoryPerformanceSeries {
    final labels = switch (_range) {
      DashboardRange.day => ['00', '04', '08', '12', '16', '20', '24'],
      DashboardRange.week => ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      DashboardRange.month => ['W1', 'W2', 'W3', 'W4'],
      DashboardRange.quarter => ['M1', 'M2', 'M3'],
      DashboardRange.year => ['Q1', 'Q2', 'Q3', 'Q4'],
      DashboardRange.custom => ['S1', 'S2', 'S3', 'S4', 'S5'],
    };
    return labels.asMap().entries.map((entry) {
      final base = overallOee - 6 + (entry.key * 2.3);
      return MachineMetricPoint(label: entry.value, value: base.clamp(55, 99).toDouble());
    }).toList(growable: false);
  }

  List<Machine> get topDowntimeMachines {
    final sorted = [..._machines]..sort((a, b) => _downtimeScore(b).compareTo(_downtimeScore(a)));
    return sorted.take(5).toList(growable: false);
  }

  List<Machine> get topEnergyMachines {
    final sorted = [..._machines]..sort((a, b) => b.power.compareTo(a.power));
    return sorted.take(5).toList(growable: false);
  }

  Future<void> _initialize() async {
    _prefs = await SharedPreferences.getInstance();
    await _restoreCachedState();

    final bootstrap = await FirebaseBootstrap.initialize();
    _firebaseEnabled = bootstrap.configured;
    _firebaseStatus = bootstrap.message;

    if (_firebaseEnabled) {
      _firebase = FirebaseSyncService();
      await _firebase!.seedIfEmpty(_machines, _users);
      await _loadRemoteSettings();
      _bindRemoteStreams();
    }

    _isBootstrapping = false;
    notifyListeners();
  }

  void _bindRemoteStreams() {
    final service = _firebase;
    if (service == null) return;

    _machineSubscription?.cancel();
    _userSubscription?.cancel();

    _machineSubscription = service.watchMachines().listen((remoteMachines) {
      if (remoteMachines.isEmpty) return;
      _machines = remoteMachines;
      _persistCachedState();
      notifyListeners();
    });

    _userSubscription = service.watchUsers().listen((remoteUsers) {
      if (remoteUsers.isEmpty) return;
      _users = remoteUsers;
      final updatedUser = _users.firstWhereOrNull((user) => user.email == _currentUser.email);
      if (updatedUser != null) {
        _currentUser = updatedUser;
      }
      _persistCachedState();
      notifyListeners();
    });
  }

  Future<void> _restoreCachedState() async {
    final prefs = _prefs;
    if (prefs == null) return;

    final machineJson = prefs.getString('machines_cache');
    if (machineJson != null && machineJson.isNotEmpty) {
      final decoded = jsonDecode(machineJson) as List<dynamic>;
      _machines = decoded
          .map((item) => Machine.fromMap(Map<String, dynamic>.from(item as Map)))
          .toList(growable: false);
    }

    final userJson = prefs.getString('users_cache');
    if (userJson != null && userJson.isNotEmpty) {
      final decoded = jsonDecode(userJson) as List<dynamic>;
      _users = decoded
          .map((item) => AppUser.fromMap(Map<String, dynamic>.from(item as Map)))
          .toList(growable: false);
    }

    final isDark = prefs.getBool('theme_dark') ?? true;
    _themeMode = isDark ? ThemeMode.dark : ThemeMode.light;
    _isArabic = false;
    _notificationsEnabled = prefs.getBool('notifications_enabled') ?? true;
    _offlineMode = prefs.getBool('offline_mode') ?? true;
    temperatureThreshold = prefs.getDouble('temperature_threshold') ?? temperatureThreshold;
    vibrationThreshold = prefs.getDouble('vibration_threshold') ?? vibrationThreshold;
    powerThreshold = prefs.getDouble('power_threshold') ?? powerThreshold;

    final currentUserId = prefs.getString('current_user_id');
    final restoredUser = _users.firstWhereOrNull((user) => user.id == currentUserId);
    if (restoredUser != null) {
      _currentUser = restoredUser;
    }
  }

  Future<void> _persistCachedState() async {
    final prefs = _prefs;
    if (prefs == null) return;

    await prefs.setString('machines_cache', jsonEncode(_machines.map((machine) => machine.toMap()).toList(growable: false)));
    await prefs.setString('users_cache', jsonEncode(_users.map((user) => user.toMap()).toList(growable: false)));
    await prefs.setString('current_user_id', _currentUser.id);
    await prefs.setBool('theme_dark', _themeMode == ThemeMode.dark);
    await prefs.setBool('is_arabic', _isArabic);
    await prefs.setBool('notifications_enabled', _notificationsEnabled);
    await prefs.setBool('offline_mode', _offlineMode);
    await prefs.setDouble('temperature_threshold', temperatureThreshold);
    await prefs.setDouble('vibration_threshold', vibrationThreshold);
    await prefs.setDouble('power_threshold', powerThreshold);
  }

  Future<void> _loadRemoteSettings() async {
    final service = _firebase;
    if (service == null) return;
    final settings = await service.loadFactorySettings();
    if (settings == null) return;

    temperatureThreshold = ((settings['temperatureThreshold'] ?? temperatureThreshold) as num).toDouble();
    vibrationThreshold = ((settings['vibrationThreshold'] ?? vibrationThreshold) as num).toDouble();
    powerThreshold = ((settings['powerThreshold'] ?? powerThreshold) as num).toDouble();
    _notificationsEnabled = settings['notificationsEnabled'] ?? _notificationsEnabled;
    _offlineMode = settings['offlineMode'] ?? _offlineMode;
    _persistCachedState();
  }

  void _saveFactorySettings() {
    _persistCachedState();
    if (_firebaseEnabled && _firebase != null) {
      _firebase!.saveFactorySettings(<String, dynamic>{
        'temperatureThreshold': temperatureThreshold,
        'vibrationThreshold': vibrationThreshold,
        'powerThreshold': powerThreshold,
        'notificationsEnabled': _notificationsEnabled,
        'offlineMode': _offlineMode,
        'updatedAt': DateTime.now().toIso8601String(),
      }).catchError((_) {});
    }
  }

  Future<String?> login({required String email, required String password}) async {
    final normalizedEmail = email.trim().toLowerCase();
    _authBusy = true;
    notifyListeners();

    try {
      if (_firebaseEnabled && _firebase != null) {
        await _firebase!.signIn(normalizedEmail, password);
        final remoteUser = await _firebase!.fetchUserByEmail(normalizedEmail);
        if (remoteUser != null) {
          _currentUser = remoteUser;
        } else {
          final fallback = _users.firstWhereOrNull((user) => user.email == normalizedEmail);
          if (fallback != null) {
            _currentUser = fallback;
          }
        }
        _firebaseStatus = 'Firebase auth connected for ${_currentUser.email}';
      } else {
        final localUser = _users.firstWhereOrNull((user) => user.email == normalizedEmail);
        if (localUser != null) {
          _currentUser = localUser;
        }
        _firebaseStatus = 'Demo sign-in active. Firebase is ready once you paste real options.';
      }

      _isLoggedIn = true;
      if (_firebaseEnabled) {
        _simulator?.cancel();
      } else {
        _startSimulator();
      }
      await _persistCachedState();
      return null;
    } on FirebaseAuthException catch (error) {
      return error.message ?? 'Authentication failed.';
    } catch (error) {
      return 'Login failed: $error';
    } finally {
      _authBusy = false;
      notifyListeners();
    }
  }

  void logout() {
    _isLoggedIn = false;
    _selectedMachineId = null;
    _currentTab = AppTab.machines;
    _simulator?.cancel();
    if (_firebaseEnabled && _firebase != null) {
      _firebase!.signOut().catchError((_) {});
    }
    notifyListeners();
  }

  void setTab(AppTab tab) {
    _currentTab = tab;
    if (tab != AppTab.dashboard) {
      _selectedMachineId = null;
    }
    notifyListeners();
  }

  void openMachineDetail(String machineId) {
    _selectedMachineId = machineId;
    _currentTab = AppTab.dashboard;
    notifyListeners();
  }

  void backToMachines() {
    _selectedMachineId = null;
    _currentTab = AppTab.machines;
    notifyListeners();
  }

  void setRange(DashboardRange value) {
    _range = value;
    notifyListeners();
  }

  void toggleTheme(bool dark) {
    _themeMode = dark ? ThemeMode.dark : ThemeMode.light;
    _persistCachedState();
    notifyListeners();
  }

  void toggleLanguage(bool arabic) {
    _isArabic = false;
    _persistCachedState();
    notifyListeners();
  }

  void toggleNotifications(bool value) {
    _notificationsEnabled = value;
    _saveFactorySettings();
    notifyListeners();
  }

  void toggleOfflineMode(bool value) {
    _offlineMode = value;
    _saveFactorySettings();
    notifyListeners();
  }

  void switchRole(AppRole role) {
    final match = _users.firstWhereOrNull((user) => user.role == role);
    if (match != null) {
      _currentUser = match;
      _persistCachedState();
      notifyListeners();
    }
  }

  Future<void> syncNow() async {
    final service = _firebase;
    if (!_firebaseEnabled || service == null) {
      _firebaseStatus = 'Firebase is not configured yet.';
      notifyListeners();
      return;
    }

    _syncBusy = true;
    _firebaseStatus = 'Syncing machines, users, and settings...';
    notifyListeners();

    try {
      for (final machine in _machines) {
        await service.upsertMachine(machine);
      }
      for (final user in _users) {
        await service.upsertUser(user);
      }
      await service.saveFactorySettings(<String, dynamic>{
        'temperatureThreshold': temperatureThreshold,
        'vibrationThreshold': vibrationThreshold,
        'powerThreshold': powerThreshold,
        'notificationsEnabled': _notificationsEnabled,
        'offlineMode': _offlineMode,
        'updatedAt': DateTime.now().toIso8601String(),
      });
      _firebaseStatus = 'Firestore sync complete.';
    } catch (error) {
      _firebaseStatus = 'Sync failed: $error';
    } finally {
      _syncBusy = false;
      notifyListeners();
    }
  }

  void addMachine(Machine machine) {
    _machines = [..._machines, machine];
    _pushHistory('Machine added', '${machine.name} (${machine.code}) was added by admin.', Icons.add_box_rounded, DT.cyan);
    _persistCachedState();
    if (_firebaseEnabled && _firebase != null) {
      _firebase!.upsertMachine(machine).catchError((_) {});
    }
    notifyListeners();
  }

  void updateMachine(Machine machine) {
    _machines = _machines.map((item) => item.id == machine.id ? machine : item).toList(growable: false);
    _pushHistory('Machine updated', '${machine.name} configuration was updated.', Icons.edit_rounded, DT.blue);
    _persistCachedState();
    if (_firebaseEnabled && _firebase != null) {
      _firebase!.upsertMachine(machine).catchError((_) {});
    }
    notifyListeners();
  }

  void deleteMachine(String machineId) {
    final target = _machines.firstWhereOrNull((machine) => machine.id == machineId);
    _machines = _machines.where((machine) => machine.id != machineId).toList(growable: false);
    if (_selectedMachineId == machineId) {
      _selectedMachineId = null;
    }
    if (target != null) {
      _pushHistory('Machine removed', '${target.name} was removed from the factory roster.', Icons.delete_forever_rounded, DT.red);
    }
    _persistCachedState();
    if (_firebaseEnabled && _firebase != null) {
      _firebase!.deleteMachine(machineId).catchError((_) {});
    }
    notifyListeners();
  }

  void addUser(AppUser user) {
    _users = [..._users, user];
    _pushHistory('User added', '${user.name} joined as ${user.role.name}.', Icons.person_add_alt_1_rounded, DT.cyan);
    _persistCachedState();
    if (_firebaseEnabled && _firebase != null) {
      _firebase!.upsertUser(user).catchError((_) {});
    }
    notifyListeners();
  }

  void updateUser(AppUser user) {
    _users = _users.map((item) => item.id == user.id ? user : item).toList(growable: false);
    if (_currentUser.id == user.id) {
      _currentUser = user;
    }
    _pushHistory('User updated', '${user.name} profile was updated.', Icons.manage_accounts_rounded, DT.blue);
    _persistCachedState();
    if (_firebaseEnabled && _firebase != null) {
      _firebase!.upsertUser(user).catchError((_) {});
    }
    notifyListeners();
  }

  void deleteUser(String userId) {
    if (_currentUser.id == userId) return;
    final target = _users.firstWhereOrNull((user) => user.id == userId);
    _users = _users.where((user) => user.id != userId).toList(growable: false);
    if (target != null) {
      _pushHistory('User removed', '${target.name} was removed from access control.', Icons.person_remove_alt_1_rounded, DT.red);
    }
    _persistCachedState();
    if (_firebaseEnabled && _firebase != null) {
      _firebase!.deleteUser(userId).catchError((_) {});
    }
    notifyListeners();
  }

  void startMachine(String machineId) {
    _updateStatus(machineId, MachineStatus.running, 'Machine started', 'Production resumed by operator.', clearAlert: true);
  }

  void stopMachine(String machineId) {
    _updateStatus(machineId, MachineStatus.stopped, 'Machine stopped', 'Machine stopped manually from quick actions.', alert: 'Stopped by operator');
  }

  void requestMaintenance(String machineId) {
    _updateStatus(machineId, MachineStatus.maintenance, 'Maintenance requested', 'Maintenance ticket created and routed.', alert: 'Maintenance request sent');
  }

  void reportIssue(String machineId) {
    _updateStatus(machineId, MachineStatus.fault, 'Issue reported', 'Critical issue escalated to maintenance team.', alert: 'Operator reported a critical issue');
  }

  void updateThresholds({double? temperature, double? vibration, double? power}) {
    if (temperature != null) temperatureThreshold = temperature;
    if (vibration != null) vibrationThreshold = vibration;
    if (power != null) powerThreshold = power;
    _saveFactorySettings();
    notifyListeners();
  }

  void _updateStatus(String machineId, MachineStatus status, String title, String detail, {String? alert, bool clearAlert = false}) {
    final machine = _machines.firstWhereOrNull((item) => item.id == machineId);
    if (machine == null) return;
    final updated = machine.copyWith(
      status: status,
      activeAlert: alert,
      clearAlert: clearAlert,
      lastUpdated: DateTime.now(),
      timeline: [
        MachineTimelineEvent(time: DateTime.now(), title: title, detail: detail, color: _statusColor(status)),
        ...machine.timeline,
      ].take(5).toList(growable: false),
    );
    updateMachine(updated);
    if (alert != null) {
      _alerts.insert(
        0,
        AppAlert(
          id: '${machine.id}-${DateTime.now().millisecondsSinceEpoch}',
          machineId: machine.id,
          title: title,
          message: '${machine.name}: $alert',
          time: DateTime.now(),
          color: _statusColor(status),
        ),
      );
    }
  }

  void _startSimulator() {
    if (_firebaseEnabled) return;
    _simulator?.cancel();
    _simulator = Timer.periodic(const Duration(seconds: 5), (_) {
      _machines = _machines.map((machine) {
        if (machine.status == MachineStatus.stopped || machine.status == MachineStatus.maintenance) {
          return machine;
        }
        final delta = _random.nextDouble() * 4 - 2;
        final vibDelta = _random.nextDouble() * 0.08 - 0.04;
        final eff = (machine.efficiency + delta).round().clamp(35, 99);
        final temp = (machine.temperature + delta).clamp(24, 96).toDouble();
        final vibration = (machine.vibration + vibDelta).clamp(0.05, 0.92).toDouble();
        final power = (machine.power + (_random.nextDouble() * 1.4 - 0.7)).clamp(0.4, 32).toDouble();
        final prod = machine.productionCount + (machine.status == MachineStatus.running ? _random.nextInt(12) : 0);
        MachineStatus status = machine.status;
        String? alert = machine.activeAlert;
        if (temp >= temperatureThreshold || vibration >= vibrationThreshold || power >= powerThreshold) {
          status = MachineStatus.fault;
          alert = 'Threshold exceeded';
        } else if (machine.status == MachineStatus.fault) {
          status = MachineStatus.running;
          alert = null;
        }
        return machine.copyWith(
          efficiency: eff,
          temperature: temp,
          vibration: vibration,
          power: power,
          productionCount: prod,
          activeAlert: alert,
          clearAlert: alert == null,
          status: status,
          lastUpdated: DateTime.now(),
          performanceSeries: [
            ...machine.performanceSeries.skip(1),
            MachineMetricPoint(label: '${DateTime.now().hour}:${DateTime.now().minute.toString().padLeft(2, '0')}', value: eff.toDouble()),
          ],
        );
      }).toList(growable: false);
      _persistCachedState();
      notifyListeners();
    });
  }

  void _seedLogs() {
    final now = DateTime.now();
    _history.addAll([
      HistoryLog(id: 'h1', time: now.subtract(const Duration(minutes: 5)), title: 'Welding fault detected', subtitle: 'Arc quality alarm triggered automatic stop.', icon: Icons.error_outline_rounded, color: DT.red),
      HistoryLog(id: 'h2', time: now.subtract(const Duration(minutes: 14)), title: 'Hydraulic maintenance started', subtitle: 'Maintenance ticket assigned to Mariam.', icon: Icons.build_circle_rounded, color: DT.yellow),
      HistoryLog(id: 'h3', time: now.subtract(const Duration(minutes: 24)), title: 'Packaging target achieved', subtitle: 'Packaging Unit reached 1260 items.', icon: Icons.verified_rounded, color: DT.green),
    ]);
    _alerts.addAll([
      AppAlert(id: 'a1', machineId: 'wld-06', title: 'Critical fault', message: 'Welding Robot exceeded vibration threshold.', time: now.subtract(const Duration(minutes: 6)), color: DT.red),
      AppAlert(id: 'a2', machineId: 'hyd-03', title: 'Maintenance active', message: 'Hydraulic Press is under planned maintenance.', time: now.subtract(const Duration(minutes: 12)), color: DT.yellow),
    ]);
  }

  void _pushHistory(String title, String subtitle, IconData icon, Color color) {
    _history.insert(0, HistoryLog(id: '${DateTime.now().millisecondsSinceEpoch}', time: DateTime.now(), title: title, subtitle: subtitle, icon: icon, color: color));
  }

  double _downtimeScore(Machine machine) {
    return switch (machine.status) {
      MachineStatus.fault => 10,
      MachineStatus.maintenance => 7,
      MachineStatus.stopped => 5,
      MachineStatus.offline => 3,
      MachineStatus.running => 1,
    } +
        (100 - machine.efficiency) / 20;
  }

  Color _statusColor(MachineStatus status) {
    switch (status) {
      case MachineStatus.running:
        return DT.green;
      case MachineStatus.maintenance:
        return DT.yellow;
      case MachineStatus.fault:
        return DT.red;
      case MachineStatus.stopped:
        return DT.purple;
      case MachineStatus.offline:
        return DT.blue;
    }
  }

  @override
  void dispose() {
    _simulator?.cancel();
    _machineSubscription?.cancel();
    _userSubscription?.cancel();
    super.dispose();
  }
}

extension<T> on Iterable<T> {
  T? firstWhereOrNull(bool Function(T element) test) {
    for (final element in this) {
      if (test(element)) return element;
    }
    return null;
  }
}
