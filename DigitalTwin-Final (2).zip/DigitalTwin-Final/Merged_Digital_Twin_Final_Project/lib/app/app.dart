import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../screens/login_screen.dart';
import '../theme/dt_colors.dart';
import 'routes.dart';
import 'state.dart';

class DigitalTwinApp extends StatelessWidget {
  const DigitalTwinApp({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();

    final darkTheme = ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: DT.bg,
      useMaterial3: true,
      colorScheme: const ColorScheme.dark(primary: DT.cyan, secondary: DT.blue),
      appBarTheme: const AppBarTheme(backgroundColor: Colors.transparent, elevation: 0),
      inputDecorationTheme: _inputDecorationTheme(),
    );

    final lightTheme = ThemeData(
      brightness: Brightness.light,
      scaffoldBackgroundColor: const Color(0xFFF5F7FB),
      useMaterial3: true,
      colorScheme: const ColorScheme.light(primary: DT.blue, secondary: DT.cyan),
      appBarTheme: const AppBarTheme(backgroundColor: Colors.transparent, elevation: 0),
      inputDecorationTheme: _inputDecorationTheme(light: true),
    );

    return Directionality(
      textDirection: TextDirection.ltr,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        themeMode: app.themeMode,
        theme: lightTheme,
        darkTheme: darkTheme,
        home: app.isBootstrapping
            ? const _BootScreen()
            : (app.isLoggedIn ? const AppShell() : const LoginScreen()),
      ),
    );
  }

  InputDecorationTheme _inputDecorationTheme({bool light = false}) {
    final fill = light ? Colors.white : const Color(0xFF0B1220).alphaF(0.65);
    final borderColor = light ? const Color(0xFFD5DCEA) : DT.border(0.8);
    return InputDecorationTheme(
      filled: true,
      fillColor: fill,
      hintStyle: TextStyle(color: light ? Colors.black45 : DT.dim(0.45)),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: borderColor)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: DT.cyan, width: 1.4)),
    );
  }
}

class _BootScreen extends StatelessWidget {
  const _BootScreen();

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF020617), Color(0xFF0B1220), Color(0xFF0B2940)],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 86,
                height: 86,
                decoration: BoxDecoration(
                  gradient: DT.grad,
                  borderRadius: BorderRadius.circular(28),
                  boxShadow: [BoxShadow(color: DT.cyan.alphaF(0.22), blurRadius: 24, offset: const Offset(0, 12))],
                ),
                child: const Icon(Icons.factory_rounded, color: Colors.white, size: 40),
              ),
              const SizedBox(height: 20),
              const CircularProgressIndicator(color: DT.cyan),
              const SizedBox(height: 16),
              const Text('Initializing Smart Factory', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 28),
                child: Text(app.firebaseStatus, textAlign: TextAlign.center, style: TextStyle(color: DT.muted(0.62), fontWeight: FontWeight.w600)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
