import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../models/app_user.dart';
import '../models/machine.dart';

class FirebaseSyncService {
  FirebaseSyncService()
      : _firestore = FirebaseFirestore.instance,
        _auth = FirebaseAuth.instance;

  final FirebaseFirestore _firestore;
  final FirebaseAuth _auth;

  Stream<List<Machine>> watchMachines() {
    return _firestore
        .collection('machines')
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => Machine.fromMap(doc.data(), fallbackId: doc.id))
            .toList(growable: false)
          ..sort((a, b) => a.code.compareTo(b.code)));
  }

  Stream<List<AppUser>> watchUsers() {
    return _firestore
        .collection('users')
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => AppUser.fromMap(doc.data(), fallbackId: doc.id))
            .toList(growable: false)
          ..sort((a, b) => a.name.compareTo(b.name)));
  }

  Future<void> seedIfEmpty(List<Machine> machines, List<AppUser> users) async {
    final machineCollection = _firestore.collection('machines');
    final userCollection = _firestore.collection('users');

    final machineSnapshot = await machineCollection.limit(1).get();
    if (machineSnapshot.docs.isEmpty) {
      final batch = _firestore.batch();
      for (final machine in machines) {
        batch.set(machineCollection.doc(machine.id), machine.toMap());
      }
      await batch.commit();
    }

    final userSnapshot = await userCollection.limit(1).get();
    if (userSnapshot.docs.isEmpty) {
      final batch = _firestore.batch();
      for (final user in users) {
        batch.set(userCollection.doc(user.id), user.toMap());
      }
      await batch.commit();
    }
  }

  Future<void> signIn(String email, String password) {
    return _auth.signInWithEmailAndPassword(email: email, password: password);
  }

  Future<void> signOut() {
    return _auth.signOut();
  }

  Future<AppUser?> fetchUserByEmail(String email) async {
    final result = await _firestore
        .collection('users')
        .where('email', isEqualTo: email.trim().toLowerCase())
        .limit(1)
        .get();

    if (result.docs.isEmpty) {
      return null;
    }

    return AppUser.fromMap(result.docs.first.data(), fallbackId: result.docs.first.id);
  }

  Future<void> upsertMachine(Machine machine) {
    return _firestore.collection('machines').doc(machine.id).set(machine.toMap());
  }

  Future<void> deleteMachine(String machineId) {
    return _firestore.collection('machines').doc(machineId).delete();
  }

  Future<void> upsertUser(AppUser user) {
    return _firestore.collection('users').doc(user.id).set(user.toMap());
  }

  Future<void> deleteUser(String userId) {
    return _firestore.collection('users').doc(userId).delete();
  }

  Future<Map<String, dynamic>?> loadFactorySettings() async {
    final snapshot = await _firestore.collection('config').doc('app').get();
    return snapshot.data();
  }

  Future<void> saveFactorySettings(Map<String, dynamic> data) {
    return _firestore.collection('config').doc('app').set(data, SetOptions(merge: true));
  }
}
